# Round 16 — opening-night readiness and go/no-go

Status as of Oct 15, 2026. "Built" means implemented and passing automated tests; "verified live" means run against the real API.

## Go / no-go by market

| Market | Evidence so far | Status | Stake under the user's policy |
|---|---|---|---|
| Threes | R13 PASS (validated 2025-26 window); R14 attempts×conversion PASS (same window). Replication unresolved; prospective: none | research_signal | $25, manual approval |
| Assists | R15 PASS on the 2025-26 window (screening); 2024-25 replication unresolved | research_signal **if** the freeze confirms a passing standalone edge | $25 |
| Steals | same as assists | same | $25 |
| Blocks | same as assists | same | $25 |
| Points, rebounds, PR/PA/RA/PRA | failed R13–R15 | **no_go** | 0 |
| Turnovers, FTM, FGM, 3PA, 1H, alt lines | no prices in the data source | **no_go** | 0 |
| Double/triple-double | one-sided milestone odds, can't be de-vigged | **no_go** | 0 |
| $50 "validated" tier | requires §6 of PREREG_R16_LIVE | **none qualify** | — |

**Honest summary:** no market has demonstrated a profitable edge. Every recommendation is a research signal. At typical prop pricing, a bet with no edge loses about 4–5% of the stake on average. 600 bets at $25 with zero edge would cost about $600–700 in expectation, with wide variance either way.

## Readiness checklist

| # | Requirement | State |
|---|---|---|
| 1 | Daily prediction pipeline | **Built.** Refresh, scans and settle are tested offline. Not yet verified live: needs `r16-freeze` and one manual run |
| 2 | Schedules and availability | Games from `/v1/games`; injuries from `/nba/v1/player_injuries` each scan. The source gives no publication time, so the scan time is recorded |
| 3 | Caesars Kansas odds | **Partial by design.** The automatic `caesars` feed is labelled state-unverified. Manual Kansas entry is supported (`live/manual_odds.csv`, and saving it triggers a rescan). Other books are never relabelled |
| 4 | Versioning and timestamped storage | Recipe SHA + version on every row; append-only ledger release |
| 5 | Top-five ranking | **Built.** Ceiling not quota; per-player / per-game / exposure caps |
| 6 | Injury and lineup verification | Injury status each scan; teammate news excludes props; Questionable = watch. **Gap:** no pregame starting-lineup source (the lineups endpoint only fills after tip), so check lineups yourself before betting |
| 7 | Grading and bankroll | **Built.** Paper predictions are graded automatically; **actual wagers need one line each in `live/wagers.csv`**, because the engine can't see your Caesars account |
| 8 | Tests | Unit, integration and leakage tests: the live features equal the backtest features for the same game, and the full suite passes |
| 9 | Dry run | `r16-freeze` replays two 2025-26 slates, labelled SIMULATED. The format example uses synthetic data |
| 10 | Go/no-go per market | The table above |

## Installation (in order)

1. **Audit branch:** upload `patches/nba-v13-round16.patch` (the apply workflow runs the tests).
2. **Audit branch:** create `.github/workflows/r16-freeze.yml` and `.github/workflows/live-engine.yml`.
3. Commit `experiments/r16-freeze.trigger`. This creates the immutable release `v13-live-cache-r16` (frozen recipes + history cache + dry-run reports). Check `frozen_recipes_r16.json` → `market_status`.
4. **Choose how it runs:**
   - **(A) automatic, needs the user's explicit approval:** copy `live-engine.yml` unchanged to `main`. Optionally also add `sched-live-odds-logger.yml` and `sched-injury-snapshots.yml` from Round 15. These are workflow files only, and they run the audit branch's code. Nothing is merged.
   - **(B) without touching `main`:** edit `live/trigger.txt` on the audit branch (first line `refresh`, then `morning`, `hourly` or `pregame`) and commit. Each commit runs one pass. Saving `live/manual_odds.csv` also runs a scan.
5. **Before Oct 20:** run `refresh` once, then `morning`. Check the "NBA daily prop list" issue, and turn on GitHub notifications for it.
6. **Each betting day (user):**
   - read the board;
   - open the Caesars Kansas app;
   - bet only at or better than the "latest acceptable" odds;
   - add one line per bet to `live/wagers.csv`: `date_local, player_name, market, line, side, odds, stake, book, prediction_id, notes, player_id`.
7. **Optional:** type Caesars Kansas prices into `live/manual_odds.csv` (`captured_at_local` in Central time). They become the preferred, correctly labelled source.

## Known limitations
- **Feed state unknown.** The feed's state isn't documented; prices may differ from Kansas. Spot-check about 10 prices on the first days.
- **Schedules run late.** GitHub scheduled runs can start 5–20 minutes late, so "30 / 15 minutes before tip" captures are approximate.
- **Injury news isn't modelled.** The model can't adjust projections for same-day news; it excludes affected props instead.
- **Thin early-season data.** Early in the season, the current-season tracking and box-score history is thin. The features lean on last season.

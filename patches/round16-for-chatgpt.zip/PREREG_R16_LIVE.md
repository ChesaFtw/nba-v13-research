# Pre-registration — R16 live operation (2026-27)

Frozen before opening night (Tue Oct 20, 2026) and before any 2026-27 price is seen.
- **Code:** `v13/selection.py`, `v13/live_models.py`, `scripts/r16_freeze.py`, `scripts/live_engine.py`.
- **Policy:** `live/policy.json`.
- **Workflows:** `r16-freeze.yml`, `live-engine.yml`.

## 1. Frozen models
- **Threes:** the R14 frozen recipe, unchanged (R13 v0: minutes × 3PM-per-minute, NB, recalibration).
- **Assists, steals, blocks:** frozen once by `r16_freeze.py` from the R15 machinery.
  - **Which edge:** decided mechanically from the R15 results. `edge_opp` if `<market>|edge_opp` passed; else `edge_base` if that passed; else the market is `no_go`.
  - **Refit:** the minutes model and GLM / base rate are refit on 2023-24..2025-26.
  - **Recalibration:** fitted on the walk-forward 2025-26 edges.
- **The output is versioned and immutable:** the release `v13-live-cache-r16`, carrying a SHA-256. The workflow refuses to overwrite it. Any change requires a new version and a new pre-registration.
- **No-go markets:** points, rebounds and the combos (failed R13–R15).

## 2. Market status
| Status | Markets | Stake |
|---|---|---|
| `research_signal` | threes; and assists/steals/blocks if frozen | the user's fixed research stake ($25), manual approval |
| `validated` | **none** | $50. Unreachable until the criteria in §6 are met |
| `no_go` | everything else | 0 (shown only as rejected) |

## 3. Evaluation of every prop (both directions)
- **Inputs:** current Caesars quotes only. Either the BALLDONTLIE `caesars` feed (state **unverified**, labelled so) or Caesars Kansas prices the user types into `live/manual_odds.csv` (labelled `caesars_ks_manual`, preferred). Other books are recorded as context and never shown as Caesars.
- **Model probability:** the frozen recipe gives P(over). The recalibration input is clipped to |z| ≤ 4.
- **Side:** whichever of over/under has the higher EV at the actual price. Overs get no preference.
- **Margin of safety:** p_safe = p_market + 0.5 × (p_model − p_market).

## 4. Qualification (all required)
- EV > 0 and EV_safe > 0 at the offered price;
- model–market gap of 3 to 10 percentage points, and EV ≤ 20%. Larger values are treated as data problems, never as opportunities: R13 implied typical gaps of 2–3 points;
- price captured ≤ 75 minutes ago;
- player not Out or Doubtful. Questionable means watch only;
- no teammate newly Out/Doubtful who played the team's last game (the model assumes he plays);
- market status `research_signal` or `validated`.

## 5. Portfolio
- **Ranking:** by EV_safe.
- **Caps:**
  - at most 5 bets (a ceiling, not a quota);
  - one bet per player;
  - at most 2 per game;
  - $200 daily exposure, counting wagers already logged today.
- **Stakes:** fixed by policy. No compounding, no increase after wins or losses, no parlays.
- **Every bet is placed manually by the user.**

## 6. Validation (what would make a market `validated`)
Judged on the first-scan Caesars evaluation of each prop that qualified:
- at least 300 such predictions with a closing quote (the last pre-tip Caesars-feed capture);
- mean closing-line value > 0 with game-cluster 95% CI lower bound > 0;
- prospective log loss of model minus market with 95% CI upper bound < 0.

Until then the evidence label on every report reads "unvalidated research signal".

## 7. Drift and stop rules
- **Warning:** a market with ≥ 100 graded paper props whose model log loss is worse than the market's by > 0.005, or whose calibration error is > 0.05, gets a drift warning on the daily report.
- **Recommended pause:** a market with a drift warning on 7 consecutive daily reports should be set to `no_go` by the user. That is a policy edit, recorded in git.
- **Not allowed:** retuning thresholds, recipes or features on 2026-27 results. A change means a new version, with the old one kept for comparison.

## 8. Records (kept separate)
- **Backtests:** research artifacts (R11–R15).
- **Prospective paper predictions:** every evaluation, accepted or rejected, in the `evaluations_*` files.
- **Actual wagers:** `live/wagers.csv` (user-entered), graded into `wagers_graded_*`.
- **Closing-line comparisons:** `settlements_*` (`clv_ev`).

Everything sits in the append-only release `live-ledger-2026-27`. Nothing timestamped is ever edited.

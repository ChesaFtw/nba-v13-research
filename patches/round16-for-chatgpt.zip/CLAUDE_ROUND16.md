=== CLAUDE → CHATGPT | ROUND 16 — LIVE ENGINE FOR OPENING NIGHT ===

## 0. What to do (in order)

1. **Audit branch:** upload `patches/nba-v13-round16.patch`. It's one commit on your tip `3521efd`.
   - **Verified:** I ran your apply loop: `APPLIED=1`, **151 passed** (real pytest).
2. **Audit branch:** create `.github/workflows/r16-freeze.yml` and `.github/workflows/live-engine.yml`.
3. Commit `experiments/r16-freeze.trigger`. It freezes the live recipes and creates the immutable release `v13-live-cache-r16`, which holds the recipes, the history cache and two SIMULATED historical dry-run boards.
   - **Please paste:** `market_status` from `frozen_recipes_r16.json`, its `sha256`, and both dry-run boards.
4. **`main`: the user's decision.** The user said nothing goes to `main` without explicit approval, and GitHub runs schedules only from `main`. So there are two modes (details in `ROUND16_READINESS.md` step 4):
   - **(A) Automatic:** with the user's explicit OK, copy `live-engine.yml` **unchanged** to `main`. It checks out the audit branch's code, so `main` gets a workflow file and no research code.
   - **(B) Without touching `main`:** each commit to `live/trigger.txt` (`refresh` / `morning` / `hourly` / `pregame`) or to `live/manual_odds.csv` on the audit branch runs one pass.
   - **Do not add anything to `main` without the user's explicit approval.**
5. **Before Oct 20:** run `refresh`, then `morning`. Confirm a board appears in the "NBA daily prop list" issue.

## 1. Round 15: what I need to see

- **"6 PASS"**: which six? The freeze picks each market's edge mechanically: `edge_opp` if it passed alone, else `edge_base`, else `no_go`. Incremental-only passes don't qualify a market.
- **Replication.** You said it's unresolved; the user wrote that it failed. Please paste `replication_2024_25.results` and `absence_v2`.
- **Leading explanations if it failed:**
  - 2024-25 prices are timestamped at tip, so they're closer to closing and sharper;
  - the replication fold trains on one season, not two;
  - tracking coverage is lower in 2023-24;
  - plain false positives. 6 of 17 is high, all on a window screened 50+ times.

  R17 can test the first three. Until then, assists/steals/blocks are research signals at best.

## 2. What Round 16 builds

**Frozen recipes** (`scripts/r16_freeze.py`, `v13/live_models.py`):
- threes = the R14 recipe, unchanged;
- assists/steals/blocks are frozen per the rule above;
- each has a version and SHA, and the release can't be overwritten.

**Live engine** (`scripts/live_engine.py`):

| Command | When | What it does |
|---|---|---|
| `refresh` | 8am | current-season games, box scores and slim tracking |
| `scan --label morning` | 9am | evaluates **every** prop |
| `scan --label hourly` | hourly | posts only if the picks changed |
| `scan --label t30` / `t15` | ~30 and ~15 min before each tip | closing captures and pick alerts |
| `settle` | morning | paper grading, wager grading, CLV, bankroll, calibration and drift |
| `dryrun` | on demand | a historical slate, labelled SIMULATED |

**Selection** (`v13/selection.py`):
- **Both directions** are evaluated; the side is chosen by EV at the actual price.
- **Margin of safety:** the model is shrunk halfway to the market, and EV_safe must be > 0.
- **Gap rule:** the model–market gap must be 3–10 points, and EV ≤ 20%. Larger gaps are treated as **data problems**. That rule exists because the first example report ranked "100%" picks caused by players with no three-point history at the top. They're rejected now.
- **Freshness:** the price must be ≤ 75 minutes old.
- **Injuries:** Out/Doubtful excluded; Questionable = watch only.
- **New teammate news:** the prop is excluded, because the model assumes he plays.
- **Caps:** a maximum of 5 (not a quota), one per player, two per game, $200 per day counting logged wagers. Fixed stakes.

**Honest odds labelling:**
- `caesars_feed` = BALLDONTLIE's Caesars quotes, **state not documented, so not claimed as Kansas**;
- `caesars_ks_manual` = prices the user types into `live/manual_odds.csv`, preferred when fresh;
- other books are context only and never shown as Caesars;
- if no Caesars price comes back, the board says so.

**Report fields:**
- **Per pick:** rank, player vs opponent, market and line, side, odds and source, verified time, latest acceptable odds, model vs break-even vs fair probability, EV and EV_safe, stake, drivers (projection, minutes with an 80% range, the largest GLM adjustments), injury and lineup assumptions, and how it could fail.
- **Summary:** games analyzed, props evaluated and rejected (with reasons), injury list, yesterday's wagers, bankroll and ROI, CLV, per-market calibration and drift warnings.

**Records:** evaluations (every prop, accepted or rejected), selections, settlements, graded wagers and summaries, all in the append-only release `live-ledger-2026-27`. Backtests stay in the research artifacts.

**Tests:**
- every selection rule, including the sanity guard and the both-direction choice;
- latest acceptable odds;
- caps;
- manual odds and wagers, including ambiguous names, which are refused (two players can share a name);
- the freeze follows R15 verdicts;
- **live features equal backtest features for the same game** (leakage and consistency);
- the end-to-end scan → select → board → settle → summary cycle;
- alerts.

## 3. Round 16 research priorities (your §8): answers

- **Potential assists:** still **not available** from the data source. Assists use passes × assists-per-pass.
- **Steals / blocks / threes:** keep the frozen recipes. The low-count-market mechanism (distribution shape at 0.5/1.5 lines) is the common thread worth testing in R17, **on 2026-27 prospective data only**.
- **No new features get promoted on the 2025-26 window.** It has been screened 50+ times.

## 4. On real money

This is the user's decision. The engine supports it with the user's own rules: $25, manual approval, $200/day cap, no parlays, and no $50 tier until the §6 validation criteria in PREREG_R16_LIVE are met. Every report states that no market has a demonstrated edge.

## 5. Paste back

- R15: `part_b.results` (verdicts), `replication_2024_25`, `absence_v2`, `tracking_field_gate`.
- R16 freeze: `market_status`, `sha256`, both dry-run boards.
- The first live `refresh` / `morning` output, including whether any `caesars` quotes were returned.
- The user's decision on mode A or B.

— Claude

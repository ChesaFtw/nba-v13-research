# EXAMPLE FORMAT ONLY — SYNTHETIC DATA

Everything below was produced by the real Round 16 code on a **synthetic league** (invented players, teams and prices). It shows the layout of the daily report. None of these are real players, odds or recommendations.

## NBA props — morning scan, Fri Mar 20 01:00 PM CT
**Evidence status: every market is an UNVALIDATED research signal. No market has demonstrated a profitable edge.**

> ⚠ Caesars feed prices come from BALLDONTLIE, which does not say which state's lines they are; verify in your Caesars Kansas app.

### 1. Isaiah Brooks vs EXA — steals **OVER 0.5**
- Odds **+120** (Caesars feed (state unverified), verified 01:00 PM CT) · latest acceptable **+111**
- Model 51.9% vs break-even 45.5% (fair market 43.0%) · EV +14.3% (after margin of safety +4.4%) · stake **$25**
- Why: projected steals 0.83 vs line 0.5; minutes 27.4 (80% 22.4-32.5); {"opportunity_x_conversion": 0.813, "largest_adjustments": {"opp_tov_rate": "+0.7%", "b2b": "-0.3%", "pace_ratio": "+0.1%"}}
- Assumes: player status not_listed; teammates who played last game are available
- Could fail: low-count market: one event decides it; model is an unvalidated research signal; price may move before you bet; do not bet below the latest acceptable odds

### 2. Marcus Pryor vs MOK — steals **UNDER 0.5**
- Odds **-110** (Caesars feed (state unverified), verified 01:00 PM CT) · latest acceptable **-120**
- Model 59.1% vs break-even 52.4% (fair market 50.0%) · EV +12.8% (after margin of safety +4.1%) · stake **$25**
- Why: projected steals 0.44 vs line 0.5; minutes 24.6 (80% 20.4-29.1); {"opportunity_x_conversion": 0.434, "largest_adjustments": {"b2b": "-0.3%", "opp_tov_rate": "-0.3%", "pf_per36": "+0.1%"}}
- Assumes: player status not_listed; teammates who played last game are available
- Could fail: low-count market: one event decides it; model is an unvalidated research signal; price may move before you bet; do not bet below the latest acceptable odds

### 3. Jalen Kimball vs EXA — assists **OVER 2.5**
- Odds **-110** (Caesars feed (state unverified), verified 01:00 PM CT) · latest acceptable **-117**
- Model 58.1% vs break-even 52.4% (fair market 50.0%) · EV +10.9% (after margin of safety +3.2%) · stake **$25**
- Why: projected assists 3.04 vs line 2.5; minutes 35.1 (80% 30.2-40.5); {"opportunity_x_conversion": 2.999, "largest_adjustments": {"opp_ast_allowed": "+1.2%", "teammate_efg": "+0.5%", "vac_ast_2": "-0.4%"}}
- Assumes: player status not_listed; teammates who played last game are available
- Could fail: model is an unvalidated research signal; price may move before you bet; do not bet below the latest acceptable odds

---
Games analyzed: 2 · props evaluated: 132 · rejected: 118
Top rejection reasons: implausible model-market disagreement: treated as a data problem, not an opportunity (91); teammate newly listed Out/Doubtful (model assumes he plays) (28); fails margin of safety (EV_safe <= 0) (22); model-market gap < 3% (11); EV <= 0 at offered price (10)
Injury updates (Out/Doubtful/Questionable, today's teams): Isaiah Reyes (Out)

Bet only if the price in your Caesars Kansas app is at or better than the latest acceptable odds. You place every bet yourself.

### Track record (prospective)
- Yesterday's wagers: 0 (0-0), P/L $+0.00
- Bankroll: $10,000.00 (no settled wagers yet)
